null.roc <- structure(list(percent = FALSE, sensitivities = c(1, 0), specificities = c(0, 1), auc = NULL, class = "auc"), class = "roc")
