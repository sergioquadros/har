R_RegisterCCallable("RGtk2", "S_cairo_write_func_t", ((DL_FUNC)S_cairo_write_func_t)); 
