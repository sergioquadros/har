R_RegisterCCallable("RGtk2", "S_gtk_about_dialog_class_init", ((DL_FUNC)S_gtk_about_dialog_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_accel_group_class_init", ((DL_FUNC)S_gtk_accel_group_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_accel_label_class_init", ((DL_FUNC)S_gtk_accel_label_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_accessible_class_init", ((DL_FUNC)S_gtk_accessible_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_action_class_init", ((DL_FUNC)S_gtk_action_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_action_group_class_init", ((DL_FUNC)S_gtk_action_group_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_adjustment_class_init", ((DL_FUNC)S_gtk_adjustment_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_alignment_class_init", ((DL_FUNC)S_gtk_alignment_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_arrow_class_init", ((DL_FUNC)S_gtk_arrow_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_aspect_frame_class_init", ((DL_FUNC)S_gtk_aspect_frame_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_bin_class_init", ((DL_FUNC)S_gtk_bin_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_box_class_init", ((DL_FUNC)S_gtk_box_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_button_class_init", ((DL_FUNC)S_gtk_button_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_button_box_class_init", ((DL_FUNC)S_gtk_button_box_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_calendar_class_init", ((DL_FUNC)S_gtk_calendar_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_cell_renderer_class_init", ((DL_FUNC)S_gtk_cell_renderer_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_cell_renderer_combo_class_init", ((DL_FUNC)S_gtk_cell_renderer_combo_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_cell_renderer_pixbuf_class_init", ((DL_FUNC)S_gtk_cell_renderer_pixbuf_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_cell_renderer_progress_class_init", ((DL_FUNC)S_gtk_cell_renderer_progress_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_cell_renderer_text_class_init", ((DL_FUNC)S_gtk_cell_renderer_text_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_cell_renderer_toggle_class_init", ((DL_FUNC)S_gtk_cell_renderer_toggle_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_cell_view_class_init", ((DL_FUNC)S_gtk_cell_view_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_check_button_class_init", ((DL_FUNC)S_gtk_check_button_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_check_menu_item_class_init", ((DL_FUNC)S_gtk_check_menu_item_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_clist_class_init", ((DL_FUNC)S_gtk_clist_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_color_button_class_init", ((DL_FUNC)S_gtk_color_button_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_color_selection_class_init", ((DL_FUNC)S_gtk_color_selection_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_color_selection_dialog_class_init", ((DL_FUNC)S_gtk_color_selection_dialog_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_combo_class_init", ((DL_FUNC)S_gtk_combo_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_combo_box_class_init", ((DL_FUNC)S_gtk_combo_box_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_combo_box_entry_class_init", ((DL_FUNC)S_gtk_combo_box_entry_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_container_class_init", ((DL_FUNC)S_gtk_container_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_ctree_class_init", ((DL_FUNC)S_gtk_ctree_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_curve_class_init", ((DL_FUNC)S_gtk_curve_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_dialog_class_init", ((DL_FUNC)S_gtk_dialog_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_drawing_area_class_init", ((DL_FUNC)S_gtk_drawing_area_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_entry_class_init", ((DL_FUNC)S_gtk_entry_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_entry_completion_class_init", ((DL_FUNC)S_gtk_entry_completion_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_event_box_class_init", ((DL_FUNC)S_gtk_event_box_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_expander_class_init", ((DL_FUNC)S_gtk_expander_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_file_chooser_button_class_init", ((DL_FUNC)S_gtk_file_chooser_button_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_file_chooser_dialog_class_init", ((DL_FUNC)S_gtk_file_chooser_dialog_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_file_chooser_widget_class_init", ((DL_FUNC)S_gtk_file_chooser_widget_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_file_selection_class_init", ((DL_FUNC)S_gtk_file_selection_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_fixed_class_init", ((DL_FUNC)S_gtk_fixed_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_font_button_class_init", ((DL_FUNC)S_gtk_font_button_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_font_selection_class_init", ((DL_FUNC)S_gtk_font_selection_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_font_selection_dialog_class_init", ((DL_FUNC)S_gtk_font_selection_dialog_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_frame_class_init", ((DL_FUNC)S_gtk_frame_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_gamma_curve_class_init", ((DL_FUNC)S_gtk_gamma_curve_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_handle_box_class_init", ((DL_FUNC)S_gtk_handle_box_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_hbox_class_init", ((DL_FUNC)S_gtk_hbox_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_hbutton_box_class_init", ((DL_FUNC)S_gtk_hbutton_box_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_hpaned_class_init", ((DL_FUNC)S_gtk_hpaned_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_hruler_class_init", ((DL_FUNC)S_gtk_hruler_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_hscale_class_init", ((DL_FUNC)S_gtk_hscale_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_hscrollbar_class_init", ((DL_FUNC)S_gtk_hscrollbar_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_hseparator_class_init", ((DL_FUNC)S_gtk_hseparator_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_icon_factory_class_init", ((DL_FUNC)S_gtk_icon_factory_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_icon_theme_class_init", ((DL_FUNC)S_gtk_icon_theme_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_icon_view_class_init", ((DL_FUNC)S_gtk_icon_view_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_image_class_init", ((DL_FUNC)S_gtk_image_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_image_menu_item_class_init", ((DL_FUNC)S_gtk_image_menu_item_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_imcontext_class_init", ((DL_FUNC)S_gtk_imcontext_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_imcontext_simple_class_init", ((DL_FUNC)S_gtk_imcontext_simple_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_immulticontext_class_init", ((DL_FUNC)S_gtk_immulticontext_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_input_dialog_class_init", ((DL_FUNC)S_gtk_input_dialog_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_invisible_class_init", ((DL_FUNC)S_gtk_invisible_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_item_class_init", ((DL_FUNC)S_gtk_item_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_item_factory_class_init", ((DL_FUNC)S_gtk_item_factory_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_label_class_init", ((DL_FUNC)S_gtk_label_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_layout_class_init", ((DL_FUNC)S_gtk_layout_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_list_class_init", ((DL_FUNC)S_gtk_list_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_list_item_class_init", ((DL_FUNC)S_gtk_list_item_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_list_store_class_init", ((DL_FUNC)S_gtk_list_store_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_menu_class_init", ((DL_FUNC)S_gtk_menu_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_menu_bar_class_init", ((DL_FUNC)S_gtk_menu_bar_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_menu_item_class_init", ((DL_FUNC)S_gtk_menu_item_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_menu_shell_class_init", ((DL_FUNC)S_gtk_menu_shell_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_menu_tool_button_class_init", ((DL_FUNC)S_gtk_menu_tool_button_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_message_dialog_class_init", ((DL_FUNC)S_gtk_message_dialog_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_misc_class_init", ((DL_FUNC)S_gtk_misc_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_notebook_class_init", ((DL_FUNC)S_gtk_notebook_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_object_class_init", ((DL_FUNC)S_gtk_object_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_old_editable_class_init", ((DL_FUNC)S_gtk_old_editable_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_option_menu_class_init", ((DL_FUNC)S_gtk_option_menu_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_paned_class_init", ((DL_FUNC)S_gtk_paned_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_pixmap_class_init", ((DL_FUNC)S_gtk_pixmap_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_plug_class_init", ((DL_FUNC)S_gtk_plug_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_preview_class_init", ((DL_FUNC)S_gtk_preview_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_progress_class_init", ((DL_FUNC)S_gtk_progress_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_progress_bar_class_init", ((DL_FUNC)S_gtk_progress_bar_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_radio_action_class_init", ((DL_FUNC)S_gtk_radio_action_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_radio_button_class_init", ((DL_FUNC)S_gtk_radio_button_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_radio_menu_item_class_init", ((DL_FUNC)S_gtk_radio_menu_item_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_radio_tool_button_class_init", ((DL_FUNC)S_gtk_radio_tool_button_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_range_class_init", ((DL_FUNC)S_gtk_range_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_rc_style_class_init", ((DL_FUNC)S_gtk_rc_style_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_ruler_class_init", ((DL_FUNC)S_gtk_ruler_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_scale_class_init", ((DL_FUNC)S_gtk_scale_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_scrollbar_class_init", ((DL_FUNC)S_gtk_scrollbar_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_scrolled_window_class_init", ((DL_FUNC)S_gtk_scrolled_window_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_separator_class_init", ((DL_FUNC)S_gtk_separator_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_separator_menu_item_class_init", ((DL_FUNC)S_gtk_separator_menu_item_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_separator_tool_item_class_init", ((DL_FUNC)S_gtk_separator_tool_item_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_settings_class_init", ((DL_FUNC)S_gtk_settings_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_size_group_class_init", ((DL_FUNC)S_gtk_size_group_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_socket_class_init", ((DL_FUNC)S_gtk_socket_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_spin_button_class_init", ((DL_FUNC)S_gtk_spin_button_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_statusbar_class_init", ((DL_FUNC)S_gtk_statusbar_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_style_class_init", ((DL_FUNC)S_gtk_style_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_table_class_init", ((DL_FUNC)S_gtk_table_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_tearoff_menu_item_class_init", ((DL_FUNC)S_gtk_tearoff_menu_item_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_text_buffer_class_init", ((DL_FUNC)S_gtk_text_buffer_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_text_child_anchor_class_init", ((DL_FUNC)S_gtk_text_child_anchor_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_text_mark_class_init", ((DL_FUNC)S_gtk_text_mark_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_text_tag_class_init", ((DL_FUNC)S_gtk_text_tag_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_text_tag_table_class_init", ((DL_FUNC)S_gtk_text_tag_table_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_text_view_class_init", ((DL_FUNC)S_gtk_text_view_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_tips_query_class_init", ((DL_FUNC)S_gtk_tips_query_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_toggle_action_class_init", ((DL_FUNC)S_gtk_toggle_action_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_toggle_button_class_init", ((DL_FUNC)S_gtk_toggle_button_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_toggle_tool_button_class_init", ((DL_FUNC)S_gtk_toggle_tool_button_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_toolbar_class_init", ((DL_FUNC)S_gtk_toolbar_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_tool_button_class_init", ((DL_FUNC)S_gtk_tool_button_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_tool_item_class_init", ((DL_FUNC)S_gtk_tool_item_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_tooltips_class_init", ((DL_FUNC)S_gtk_tooltips_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_tree_model_filter_class_init", ((DL_FUNC)S_gtk_tree_model_filter_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_tree_model_sort_class_init", ((DL_FUNC)S_gtk_tree_model_sort_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_tree_selection_class_init", ((DL_FUNC)S_gtk_tree_selection_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_tree_store_class_init", ((DL_FUNC)S_gtk_tree_store_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_tree_view_class_init", ((DL_FUNC)S_gtk_tree_view_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_tree_view_column_class_init", ((DL_FUNC)S_gtk_tree_view_column_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_uimanager_class_init", ((DL_FUNC)S_gtk_uimanager_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_vbox_class_init", ((DL_FUNC)S_gtk_vbox_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_vbutton_box_class_init", ((DL_FUNC)S_gtk_vbutton_box_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_viewport_class_init", ((DL_FUNC)S_gtk_viewport_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_vpaned_class_init", ((DL_FUNC)S_gtk_vpaned_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_vruler_class_init", ((DL_FUNC)S_gtk_vruler_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_vscale_class_init", ((DL_FUNC)S_gtk_vscale_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_vscrollbar_class_init", ((DL_FUNC)S_gtk_vscrollbar_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_vseparator_class_init", ((DL_FUNC)S_gtk_vseparator_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_widget_class_init", ((DL_FUNC)S_gtk_widget_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_window_class_init", ((DL_FUNC)S_gtk_window_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_window_group_class_init", ((DL_FUNC)S_gtk_window_group_class_init)); 
#if GTK_CHECK_VERSION(2, 10, 0)
R_RegisterCCallable("RGtk2", "S_gtk_cell_renderer_accel_class_init", ((DL_FUNC)S_gtk_cell_renderer_accel_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 10, 0)
R_RegisterCCallable("RGtk2", "S_gtk_cell_renderer_spin_class_init", ((DL_FUNC)S_gtk_cell_renderer_spin_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 10, 0)
R_RegisterCCallable("RGtk2", "S_gtk_print_operation_class_init", ((DL_FUNC)S_gtk_print_operation_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 10, 0)
R_RegisterCCallable("RGtk2", "S_gtk_recent_manager_class_init", ((DL_FUNC)S_gtk_recent_manager_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 10, 0)
R_RegisterCCallable("RGtk2", "S_gtk_status_icon_class_init", ((DL_FUNC)S_gtk_status_icon_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 10, 0)
R_RegisterCCallable("RGtk2", "S_gtk_recent_chooser_menu_class_init", ((DL_FUNC)S_gtk_recent_chooser_menu_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 10, 0)
R_RegisterCCallable("RGtk2", "S_gtk_link_button_class_init", ((DL_FUNC)S_gtk_link_button_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 10, 0)
R_RegisterCCallable("RGtk2", "S_gtk_recent_chooser_widget_class_init", ((DL_FUNC)S_gtk_recent_chooser_widget_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 10, 0)
R_RegisterCCallable("RGtk2", "S_gtk_recent_chooser_dialog_class_init", ((DL_FUNC)S_gtk_recent_chooser_dialog_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 10, 0)
R_RegisterCCallable("RGtk2", "S_gtk_assistant_class_init", ((DL_FUNC)S_gtk_assistant_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 12, 0)
R_RegisterCCallable("RGtk2", "S_gtk_builder_class_init", ((DL_FUNC)S_gtk_builder_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 12, 0)
R_RegisterCCallable("RGtk2", "S_gtk_recent_action_class_init", ((DL_FUNC)S_gtk_recent_action_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 12, 0)
R_RegisterCCallable("RGtk2", "S_gtk_scale_button_class_init", ((DL_FUNC)S_gtk_scale_button_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 12, 0)
R_RegisterCCallable("RGtk2", "S_gtk_volume_button_class_init", ((DL_FUNC)S_gtk_volume_button_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 14, 0)
R_RegisterCCallable("RGtk2", "S_gtk_mount_operation_class_init", ((DL_FUNC)S_gtk_mount_operation_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 18, 0)
R_RegisterCCallable("RGtk2", "S_gtk_entry_buffer_class_init", ((DL_FUNC)S_gtk_entry_buffer_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 18, 0)
R_RegisterCCallable("RGtk2", "S_gtk_info_bar_class_init", ((DL_FUNC)S_gtk_info_bar_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 18, 0)
R_RegisterCCallable("RGtk2", "S_gtk_hsv_class_init", ((DL_FUNC)S_gtk_hsv_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 20, 0)
R_RegisterCCallable("RGtk2", "S_gtk_tool_item_group_class_init", ((DL_FUNC)S_gtk_tool_item_group_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 20, 0)
R_RegisterCCallable("RGtk2", "S_gtk_tool_palette_class_init", ((DL_FUNC)S_gtk_tool_palette_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 20, 0)
R_RegisterCCallable("RGtk2", "S_gtk_cell_renderer_spinner_class_init", ((DL_FUNC)S_gtk_cell_renderer_spinner_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 20, 0)
R_RegisterCCallable("RGtk2", "S_gtk_offscreen_window_class_init", ((DL_FUNC)S_gtk_offscreen_window_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 20, 0)
R_RegisterCCallable("RGtk2", "S_gtk_spinner_class_init", ((DL_FUNC)S_gtk_spinner_class_init));
#endif 
R_RegisterCCallable("RGtk2", "S_gtk_cell_editable_class_init", ((DL_FUNC)S_gtk_cell_editable_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_cell_layout_class_init", ((DL_FUNC)S_gtk_cell_layout_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_editable_class_init", ((DL_FUNC)S_gtk_editable_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_tree_drag_dest_class_init", ((DL_FUNC)S_gtk_tree_drag_dest_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_tree_drag_source_class_init", ((DL_FUNC)S_gtk_tree_drag_source_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_tree_model_class_init", ((DL_FUNC)S_gtk_tree_model_class_init)); 
R_RegisterCCallable("RGtk2", "S_gtk_tree_sortable_class_init", ((DL_FUNC)S_gtk_tree_sortable_class_init)); 
#if GTK_CHECK_VERSION(2, 12, 0)
R_RegisterCCallable("RGtk2", "S_gtk_buildable_class_init", ((DL_FUNC)S_gtk_buildable_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 14, 0)
R_RegisterCCallable("RGtk2", "S_gtk_tool_shell_class_init", ((DL_FUNC)S_gtk_tool_shell_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gtk_activatable_class_init", ((DL_FUNC)S_gtk_activatable_class_init));
#endif 
#if GTK_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gtk_orientable_class_init", ((DL_FUNC)S_gtk_orientable_class_init));
#endif 
