group <- cr$popGroup()
cr$setSource(group)
