### R code from vignette source 'rattle.Rnw'

###################################################
### code chunk number 1: install (eval = FALSE)
###################################################
## install.packages(rattle, dependencies=c("Depends", "Suggests"))


###################################################
### code chunk number 2: install_togaware (eval = FALSE)
###################################################
## install.packages("rattle", repos="http://rattle.togaware.com", type="source")


###################################################
### code chunk number 3: start_up (eval = FALSE)
###################################################
## library(rattle)
## rattle()


